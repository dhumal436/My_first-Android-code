package com.example.shubh.justjava;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    int quntity=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void submitOrder(View view) {


        displayPrice(quntity*5);
    }
    public void display(int number)
    {
        TextView quntText=findViewById(R.id.zero);
        quntText.setText(""+number);
    }
    public void increment(View view)
    {
        display(++quntity);
    }
    public void decrement(View view)
    {
        display(--quntity);
    }

    private void displayPrice(int number) {
        TextView priceTextView = (TextView) findViewById(R.id.zero1);
        priceTextView.setText(NumberFormat.getCurrencyInstance().format(number));
    }

}
